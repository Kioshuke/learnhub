-- ============================================================================
-- LEARNHUB — SOẠN FLASHCARD LƯU DATABASE (bảng + RLS + RPC security definer)
-- YÊU CẦU: đã chạy public.is_teacher() trước (schema.sql).
-- Chạy 1 lần trên SQL Editor.
-- ============================================================================

-- ============ 1. BẢNG ============

create table if not exists public.flashcard_sets (
  id          uuid primary key default gen_random_uuid(),
  teacher_id  text not null,
  name        text not null default '',
  category    text not null default '',
  level       text not null default '',
  description text not null default '',
  cards       jsonb not null default '[]'::jsonb,
  is_complete boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Bổ sung cột category nếu đã tạo bảng từ bản trước (tương thích migrate).
alter table public.flashcard_sets add column if not exists category text not null default '';
alter table public.flashcard_sets add column if not exists is_complete boolean not null default false;
alter table public.flashcard_sets add column if not exists sort_order int not null default 0;

-- Gán thứ tự ban đầu theo thời điểm tạo (mới nhất = 0) để đúng thứ tự đang hiển thị.
update public.flashcard_sets s
   set sort_order = r.rank
  from (
    select id, row_number() over (partition by category order by created_at desc, id) - 1 as rank
      from public.flashcard_sets
  ) r
 where s.id = r.id;

create index if not exists flashcard_sets_teacher_idx on public.flashcard_sets (teacher_id);

alter table public.flashcard_sets enable row level security;

-- ============ 2. RLS: chặn truy cập trực tiếp (mọi thao tác qua RPC) ============

drop policy if exists flashcard_sets_no_direct on public.flashcard_sets;
create policy flashcard_sets_no_direct on public.flashcard_sets
  for all to authenticated using (false) with check (false);

-- ============ 3. RPC ============

-- Xoá các hàm BẢN CŨ (chữ ký / kiểu trả về khác) trước khi tạo lại —
-- create or replace function không cho đổi kiểu trả về.
drop function if exists public.create_flashcard_set(text, text, text, jsonb);
drop function if exists public.create_flashcard_set(text, text, text, text, jsonb);
drop function if exists public.create_flashcard_set(text, text, text, text, jsonb, boolean);
drop function if exists public.teacher_flashcard_sets();
drop function if exists public.list_flashcard_sets();
drop function if exists public.get_flashcard_set(uuid);
drop function if exists public.update_flashcard_set(uuid, text, text, text, jsonb);
drop function if exists public.update_flashcard_set(uuid, text, text, text, text, jsonb);
drop function if exists public.update_flashcard_set(uuid, text, text, text, text, jsonb, boolean);
drop function if exists public.delete_flashcard_set(uuid);

-- Giáo viên tạo bộ thẻ (kèm toàn bộ thẻ). p_cards = jsonb array [{front, back, example?}].
create or replace function public.create_flashcard_set(
  p_name text,
  p_category text,
  p_level text,
  p_description text,
  p_cards jsonb,
  p_is_complete boolean default false
)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_uid text := auth.uid()::text;
  v_id uuid;
begin
  if v_uid is null or not public.is_teacher() then
    return jsonb_build_object('ok', false, 'error', 'forbidden');
  end if;
  if btrim(coalesce(p_name, '')) = '' then
    return jsonb_build_object('ok', false, 'error', 'empty_name');
  end if;
  if p_cards is null or jsonb_typeof(p_cards) <> 'array' or jsonb_array_length(p_cards) = 0 then
    return jsonb_build_object('ok', false, 'error', 'empty_cards');
  end if;
  insert into public.flashcard_sets (teacher_id, name, category, level, description, cards, is_complete)
    values (v_uid, btrim(p_name), btrim(coalesce(p_category, '')), btrim(coalesce(p_level, '')), btrim(coalesce(p_description, '')), p_cards, coalesce(p_is_complete, false))
    returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id, 'card_count', jsonb_array_length(p_cards));
end;
$$;
revoke execute on function public.create_flashcard_set(text, text, text, text, jsonb, boolean) from public;
grant execute on function public.create_flashcard_set(text, text, text, text, jsonb, boolean) to authenticated;

-- Danh sách bộ thẻ (web giáo viên — kèm số thẻ). Flashcard xài chung:
-- giáo viên/admin nào cũng thấy tất cả các bộ, không phân biệt chủ sở hữu.
-- LƯU Ý: KHÔNG lọc theo is_teacher() — bản trước từng gây trang teacher trống
-- (role chuỗi trong DB lệch chuẩn "Giáo viên"), web đã tự chặn ở guard() trước khi load.
create or replace function public.teacher_flashcard_sets()
returns table(set_id uuid, name text, category text, level text, description text, is_complete boolean, card_count bigint, created_at timestamptz, updated_at timestamptz)
language sql stable security definer
set search_path = public
as $$
  select s.id,
         s.name,
         s.category,
         s.level,
         s.description,
         s.is_complete,
         coalesce(jsonb_array_length(s.cards), 0),
         s.created_at,
         s.updated_at
    from public.flashcard_sets s
   order by s.sort_order asc, s.created_at desc;
$$;
revoke execute on function public.teacher_flashcard_sets() from public;
grant execute on function public.teacher_flashcard_sets() to authenticated;

-- Danh sách TẤT CẢ bộ thẻ (cho hub học sinh) — chỉ meta, không gửi nội dung thẻ.
-- Mọi người đều đọc được (kể cả chưa đăng nhập) vì security definer + RLS của bảng đã chặn trực tiếp.
create or replace function public.list_flashcard_sets()
returns table(set_id uuid, name text, category text, level text, description text, is_complete boolean, card_count bigint, teacher_name text, created_at timestamptz)
language sql stable security definer
set search_path = public
as $$
  select s.id,
         s.name,
         s.category,
         s.level,
         s.description,
         s.is_complete,
         coalesce(jsonb_array_length(s.cards), 0),
         coalesce(u.name, ''),
         s.created_at
    from public.flashcard_sets s
    left join public.users u on u.id = s.teacher_id
   order by s.sort_order asc, s.created_at desc;
$$;
revoke execute on function public.list_flashcard_sets() from public;
grant execute on function public.list_flashcard_sets() to anon, authenticated;

-- Lấy 1 bộ từ đầy đủ (để vào học — flash.html?set=<id>). Mọi người đều đọc được.
create or replace function public.get_flashcard_set(p_set_id uuid)
returns table(set_id uuid, name text, category text, level text, description text, is_complete boolean, cards jsonb, teacher_name text)
language sql stable security definer
set search_path = public
as $$
  select s.id, s.name, s.category, s.level, s.description, s.is_complete, s.cards, coalesce(u.name, '')
    from public.flashcard_sets s
    left join public.users u on u.id = s.teacher_id
   where s.id = p_set_id;
$$;
revoke execute on function public.get_flashcard_set(uuid) from public;
grant execute on function public.get_flashcard_set(uuid) to anon, authenticated;

-- Cập nhật 1 bộ thẻ (chỉ giáo viên — flashcard xài chung). Thay meta + thay toàn bộ thẻ.
create or replace function public.update_flashcard_set(
  p_set_id uuid,
  p_name text,
  p_category text,
  p_level text,
  p_description text,
  p_cards jsonb,
  p_is_complete boolean default null
)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
begin
  if p_set_id is null then
    return jsonb_build_object('ok', false, 'error', 'invalid');
  end if;
  if not public.is_teacher() then
    return jsonb_build_object('ok', false, 'error', 'forbidden');
  end if;
  if btrim(coalesce(p_name, '')) = '' then
    return jsonb_build_object('ok', false, 'error', 'empty_name');
  end if;
  if p_cards is null or jsonb_typeof(p_cards) <> 'array' or jsonb_array_length(p_cards) = 0 then
    return jsonb_build_object('ok', false, 'error', 'empty_cards');
  end if;
  update public.flashcard_sets
     set name        = btrim(p_name),
         category    = btrim(coalesce(p_category, '')),
         level       = btrim(coalesce(p_level, '')),
         description = btrim(coalesce(p_description, '')),
         is_complete = coalesce(p_is_complete, is_complete),
         cards       = p_cards,
         updated_at  = now()
   where id = p_set_id;
  return jsonb_build_object('ok', true, 'id', p_set_id, 'card_count', jsonb_array_length(p_cards));
end;
$$;
revoke execute on function public.update_flashcard_set(uuid, text, text, text, text, jsonb, boolean) from public;
grant execute on function public.update_flashcard_set(uuid, text, text, text, text, jsonb, boolean) to authenticated;

-- Xoá 1 bộ thẻ (chỉ giáo viên — flashcard xài chung).
create or replace function public.delete_flashcard_set(p_set_id uuid)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
begin
  if p_set_id is null then
    return jsonb_build_object('ok', false, 'error', 'invalid');
  end if;
  if not public.is_teacher() then
    return jsonb_build_object('ok', false, 'error', 'forbidden');
  end if;
  delete from public.flashcard_sets where id = p_set_id;
  return jsonb_build_object('ok', true);
end;
$$;

-- Sắp xếp thứ tự nhiều bộ từ 1 lượt (chỉ giáo viên — kéo thả trên hub flashcard).
-- p_ranked là mảng: [{"set_id": uuid, "position": int}, ...].
-- KHÔNG lọc theo teacher_id: các bộ từ import chung chủ nên mọi giáo viên cùng sắp thứ tự chung.
create or replace function public.reorder_flashcard_sets(p_ranked jsonb)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_item jsonb;
begin
  if not public.is_teacher() then
    return jsonb_build_object('ok', false, 'error', 'forbidden');
  end if;
  if p_ranked is null or jsonb_typeof(p_ranked) <> 'array' then
    return jsonb_build_object('ok', false, 'error', 'bad_args');
  end if;
  for v_item in select * from jsonb_array_elements(p_ranked) loop
    update public.flashcard_sets s
       set sort_order = coalesce((v_item->>'position')::int, 0)
     where s.id = (v_item->>'set_id')::uuid;
  end loop;
  return jsonb_build_object('ok', true);
end;
$$;
revoke execute on function public.reorder_flashcard_sets(jsonb) from public;
grant execute on function public.reorder_flashcard_sets(jsonb) to authenticated;
-- ============ 4. NHÓM BỘ THẺ (group: sửa tên + trạng thái riêng của nhóm) ============

create table if not exists public.flashcard_groups (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique,
  is_complete boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Seed: mỗi category đang có trong bảng → 1 nhóm (is_complete mặc định false).
insert into public.flashcard_groups (name)
  select distinct btrim(category)
    from public.flashcard_sets
   where btrim(category) <> ''
  on conflict (name) do nothing;

alter table public.flashcard_groups enable row level security;

drop policy if exists flashcard_groups_no_direct on public.flashcard_groups;
create policy flashcard_groups_no_direct on public.flashcard_groups
  for all to authenticated using (false) with check (false);

drop function if exists public.list_flashcard_groups();
drop function if exists public.rename_flashcard_group(text, text);
drop function if exists public.set_flashcard_group_complete(text, boolean);

-- Danh sách nhóm (hub + web giáo viên) — ai cũng đọc được.
create or replace function public.list_flashcard_groups()
returns table(group_id uuid, name text, is_complete boolean, set_count bigint)
language sql stable security definer
set search_path = public
as $$
  select g.id, g.name, g.is_complete,
         (select count(*) from public.flashcard_sets s where s.category = g.name)
    from public.flashcard_groups g
   order by g.name;
$$;
revoke execute on function public.list_flashcard_groups() from public;
grant execute on function public.list_flashcard_groups() to anon, authenticated;

-- Giáo viên đổi tên nhóm (đổi luôn category của các bộ trong nhóm).
create or replace function public.rename_flashcard_group(
  p_old_name text,
  p_new_name text
)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_old text := btrim(coalesce(p_old_name, ''));
  v_new text := btrim(coalesce(p_new_name, ''));
begin
  if v_new = '' then
    return jsonb_build_object('ok', false, 'error', 'empty_name');
  end if;
  if not public.is_teacher() then
    return jsonb_build_object('ok', false, 'error', 'forbidden');
  end if;
  if exists (select 1 from public.flashcard_groups where name = v_new and name <> v_old) then
    return jsonb_build_object('ok', false, 'error', 'duplicate');
  end if;
  update public.flashcard_groups set name = v_new, updated_at = now() where name = v_old;
  update public.flashcard_sets set category = v_new where category = v_old;
  insert into public.flashcard_groups (name)
    select v_new
     where not exists (select 1 from public.flashcard_groups where name = v_new);
  return jsonb_build_object('ok', true);
end;
$$;
revoke execute on function public.rename_flashcard_group(text, text) from public;
grant execute on function public.rename_flashcard_group(text, text) to authenticated;

-- Giáo viên bật/tắt "nhóm đã hoàn thành" (tự tạo nhóm nếu category chưa có record).
create or replace function public.set_flashcard_group_complete(
  p_name text,
  p_is_complete boolean
)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_name text := btrim(coalesce(p_name, ''));
begin
  if v_name = '' then
    return jsonb_build_object('ok', false, 'error', 'invalid');
  end if;
  if not public.is_teacher() then
    return jsonb_build_object('ok', false, 'error', 'forbidden');
  end if;
  insert into public.flashcard_groups (name, is_complete)
    values (v_name, coalesce(p_is_complete, false))
    on conflict (name) do update
      set is_complete = excluded.is_complete, updated_at = now();
  return jsonb_build_object('ok', true);
end;
$$;
revoke execute on function public.set_flashcard_group_complete(text, boolean) from public;
grant execute on function public.set_flashcard_group_complete(text, boolean) to authenticated;